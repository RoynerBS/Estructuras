#include "Grafo.h"



bool Grafo::GetArista(int i, int j)
{
	int indice = 0;
	while (indice < cantidadvertices) 
	{
		if (vertices[indice].getvalor == i) //comprueba el valor dentro del vertice que se encuentra en el vector, para buscar ese i
		{
			int indice2 = 0;
			while (indice2 < vertices[indice].getcantidadaristas)  //while para recorrer el vector de aristas que tiene el vertice
			{
				if (vertices[indice].getaristas[indice2].getvalorj == j)  // comprueba el valor que tiene la arista como vertice de llegada o final, el valor j. Si lo encuentra entra y saca el peso.
				{
					std::cout << i ,"---",vertices[indice].getaristas[indice2].getpeso,"-->",j;
					return true;
				
				}
				else 
				{
					indice2 += 1;
				}
			}
			std::cout << "BOT Chonga: Error"; //esto es di un error de que no encontro algo
			break;
		
		
		}
		else 
		{
			indice += 1;
		}
	
	
	}
	std::cout << "BOT Yicus: Error"; // este tambien lo mismo, es 100% que va a tirar los dos mensajes seguidos cuando no encuentra xd deberia dejar solo uno
	return false;
}

bool Grafo::SetArista(int i, int j, int peso)
{
	if (GetArista(i, j) == true)
	{
		std::cout << "BOT LidioPerro: Error(ya existe xd)"; // se fija si la arista ya tiene algo, si ya existe esa relacion entre i y j. 
		return false;
	}
	else 
	{
		int indicecomp = 0; //mismo indice para recorrer
		while (indicecomp < cantidadvertices) { //while para recorrer la cantidad de vertices
			if (vertices[indicecomp].getvalor == i)  //busca el lugar en el vector en el que se encuentra este valor i y saber si existe por supuesto.
			{
				int indicecomp2 = 0; //mismo indice para recorrer x2
				while (indicecomp2 < cantidadvertices) //recorre la cantidad de vertices otra vez desde el inicio para buscar que el j exista
				{
					if (vertices[indicecomp2].getvalor == j)  //esto es para ver si lo encontr�
					{
						Arista arista = new Arista(j, peso); //creo una nueva arista, con el valor j, y el peso(Error aqui que no entiendo, porque no deja crear objetos)
						vertices[i].agregararista(arista); // en el vertice i agrego en el vector de aristas que tiene, esta arista.
						return true; //retorno true para devolver algo y salir de la funcion.
					}
					else 
					{
						indicecomp2 += 1;
					}
				
				
				}
				break;
			
			}
			else 
			{
				indicecomp += 1;
			}
		
		
		}
		std::cout << "BOT Elmer-Curio: Error(algo no existe xd)"; // esto es que di talvez la i o la j no existen, no existe ese vertice. ya que el primer if solo comprueba si existe esa relacion, no si no existe nisiquiera el vertice.
		return false; //retorna falso para devolver algo xd y salir.
	}
}

Grafo::Grafo(int x)
{
	cantidadvertices = x;
	for (int i = 0; i < x; i++)  // for para crear vertices e irlos agregando en el vector de grafo que contiene vertices. Tienen como valor el mismo numero ese del 0 al x numero.
	{
		Vertice vertice = new Vertice(i); //error que no entiendo, porque no deja crear nuevos objetos de la clase Vertice. marca en rojo el new.
		vertices.push_back(vertice);
	}
}

Grafo::~Grafo()
{
}
