#pragma once
class Arista
{

private:

	int valorj;
	int peso;

public:

	Arista(int valor, int pesso);

	int getvalorj();

	int getpeso();

};

