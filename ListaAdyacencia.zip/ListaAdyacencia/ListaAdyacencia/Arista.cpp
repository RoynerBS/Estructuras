#include "Arista.h"

Arista::Arista(int valor, int pesso)
{
	valorj = valor;
	peso = pesso;
}


int Arista::getvalorj()
{
	return valorj;
}


int Arista::getpeso()
{
	return peso;
}
