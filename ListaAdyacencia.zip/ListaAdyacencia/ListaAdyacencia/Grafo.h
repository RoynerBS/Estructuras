#pragma once
#include "Arista.h"
#include "Vertice.h"
#include <iostream>


class Grafo
{
private:

	std::vector <Vertice> vertices; //puntitos x
	int cantidadvertices; 

public:

	bool GetArista(int i, int j); //obtiene el peso de una arista
	bool SetArista(int i, int j, int peso); //establece el peso entre dos vertices

	Grafo(int x); //constructor con x cantidad de vertices a crear
	~Grafo();


};

