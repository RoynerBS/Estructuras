#include "Vertice.h"

Vertice::Vertice(int x)
{
	valori = x;
}

int Vertice::getvalor()
{
	return valori;
}

int Vertice::getcantidadaristas()
{
	return cantidadaristas;
}

void Vertice::setcantidadaristas()
{
	cantidadaristas = aristas.size;
}

std::vector<Arista> Vertice::getaristas()
{
	return aristas;
}

void Vertice::agregararista(Arista arista)
{
	aristas.push_back(arista);
}
