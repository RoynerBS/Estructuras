#pragma once
#include <vector>
#include "Arista.h"

class Vertice
{
private:
	int valori;
	int cantidadaristas;
	std::vector<Arista> aristas; //lineas conectan

public:

	Vertice(int x);

	int getvalor();

	int getcantidadaristas();
	void setcantidadaristas();
	

	std::vector<Arista> getaristas();

	void agregararista(Arista arista);
	
};

